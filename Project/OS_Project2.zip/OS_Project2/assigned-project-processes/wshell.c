//Place code here.
#include<stdio.h>
#include<string.h>
#include <unistd.h>
#include <malloc.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <sys/mman.h>
#include<sys/queue.h>

#define INPUT_MAX 1000
#define DIR_PATH_MAX 100
#define JOBS_MAX 255
#define FILE_CONTENT_MAX 10000
#define HIST_SIZE 10
#define TRUE 1
#define FALSE 0

/************ Job Table Structure ************/
typedef struct JobNode {
    int pid;
    char *cmd;
} JobNode;

typedef struct JobTable {
    int job_num;
    JobNode jobs[JOBS_MAX];
} JobTable;

/************ History Table Structure ************/
typedef struct HistNode {
    char *str;
    struct HistNode *ptr;
} HistNode;

typedef struct HistQueue {
    HistNode *head;
    HistNode *tail;
    int size;
} HistQueue;

/*********** Global Variables *************/
char buff_path[DIR_PATH_MAX];
char old_path[DIR_PATH_MAX];
char dirPath[DIR_PATH_MAX];
JobTable *job_table;
int jobs_cnt = 0;
//char *history[HIST_SIZE];
HistQueue *q = NULL;

/*********** Function *************/
void get_current_dir(char source[], char dir[]);

int exec_cmd(int cmd_flag, int cmd_num, char *input_cmd[], char input[]);

char **command_parse(char cmd[], int *num);

void hist_insert(HistQueue *q, char s[]);

int deal_cmd_operator(char input[], char *cmd[], int num);

void deal_redirect_operator(int redirect_flag, char input[]);

void deal_background_job(char cmd[]);

int cmd_judge(char cmd[]);

void prompt_show(char disp[]);

/*********** Main Program *************/
int main(int argc, char **argv) {

    job_table = mmap(NULL, sizeof(JobTable), PROT_READ | PROT_WRITE, MAP_SHARED | MAP_ANONYMOUS, -1, 0);
    q = malloc(sizeof(HistQueue));
    q->size = 0;
    q->head = malloc(sizeof(HistNode));
    q->head->ptr = NULL;
    q->tail = q->head;

    while (TRUE) {

        // Get dir path
        if (getcwd(buff_path, DIR_PATH_MAX) == NULL) {
            printf("Cannot obtain the dir path!\n");
        }

        // Shell shows directory path with prompt
        get_current_dir(buff_path, dirPath);
        prompt_show(dirPath);

        char input[INPUT_MAX];
        fgets(input, INPUT_MAX, stdin);

        hist_insert(q, input);      // Insert cmd history to table (save 10 recent commands)

        // Stdin source (from user input or files)
        if (!isatty(fileno(stdin))) {
            printf("%s", input);
            fflush(stdout);
        }

        // Enter has been pressed
        if (input[0] == '\n')
            continue;

        int num;
        char **cmd = command_parse(input, &num);

        // Operator: && and ||
        if (strstr(input, "&&") || strstr(input, "||")) {
            deal_cmd_operator(input, cmd, num);
            continue;
        }

        // Redirect Symbol: >, >>, |
        int redirect_flag = 0;
        if (strstr(input, ">>"))
            redirect_flag = 2;
        else if (strstr(input, ">"))
            redirect_flag = 1;
        else if (strstr(input, "|"))
            redirect_flag = 3;

        if (redirect_flag) {
            deal_redirect_operator(redirect_flag, input);
            continue;
        }

        // Background jobs
        if (strstr(input, "&")) {
            deal_background_job(input);
            continue;
        }

        int cmd_flag = cmd_judge(cmd[0]);
        exec_cmd(cmd_flag, num, cmd, input);

    }
}

void get_current_dir(char s[], char dir[]) {
    int len = strlen(s);
    if (len == 1) {
        dir[0] = '/';
        dir[1] = '\0';
        return;
    }

    int index = len - 1;
    while (index >= 0) {
        if (s[index] == '/') {
            index++;
            int cnt = 0;
            for (; index <= len - 1; index++) {
                dir[cnt++] = s[index];
            }
            dir[cnt] = '\0';
            return;
        }
        index--;
    }
}

char **command_parse(char cmd[], int *num) {
    char *ch[INPUT_MAX];
    int cnt = 0;
    int index = 0;
    int last = 0;
    int flag = FALSE;
    while (cmd[index] != '\0') {
        if (!flag && cmd[index] != ' ' && cmd[index] != '\n') {
            flag = TRUE;
            last = index;
        }
        if (flag && (cmd[index] == ' ' || cmd[index] == '\n')) {
            flag = FALSE;
            int len = index - last;
            char *temp = malloc(sizeof(char) * (len + 1));
            int k = 0;
            for (; k < len; k++) {
                temp[k] = cmd[last++];
            }
            temp[k] = '\0';
            ch[cnt] = temp;
            //printf("len:%d %s\n", len, temp);
            cnt++;
        }

        index++;
    }
    *num = cnt;

    char **s = malloc(sizeof(char *) * (cnt + 1));
    for (index = 0; index < cnt; index++) {
        s[index] = ch[index];
    }

    s[cnt] = NULL;
    return s;
}

/*char **command_parse(char cmd[], int *num) {
    int i;
    int cnt = 0;
    int index = 0;
    int flag = FALSE;
    while (cmd[index] != '\0') {
        //printf("%c\n", cmd[index]);
        if (flag && (cmd[index] == ' ' || cmd[index] == '\n')) {
            flag = FALSE;
            cnt++;
        } else if (cmd[index] != ' ')
            flag = TRUE;
        ++index;
    }
    *num = cnt;     // number of arguments
    char **ptr = malloc(sizeof(char *) * (cnt + 1));

    // Only one command
    if (cnt == 1) {
        // Remove character '\n' or ' '
        int index = 0;
        while (cmd[index] != '\n' && cmd[index] != ' ')
            index++;
        int len = index;
        //printf("%d\n", index);
        ptr[0] = malloc(sizeof(char *) * (len + 1));
        memcpy(ptr[0], cmd, len);
        ptr[len - 1] = '\0';

        ptr[cnt] = malloc(sizeof(char) * 5);
        ptr[cnt] = "NULL";
        return ptr;
    }

    char *temp = strtok(cmd, " ");
    int length = strlen(temp);
    ++length;
    ptr[0] = malloc(sizeof(char) * length);
    memcpy(ptr[0], temp, length);

    for (i = 1; i < cnt - 1; i++) {
        temp = strtok(NULL, " ");
        int length = strlen(temp);
        ++length;
        ptr[i] = malloc(sizeof(char) * length);
        memcpy(ptr[i], temp, length);
    }

    if (cnt != 1) {
        // Do not save the '\n' character of the last string
        temp = strtok(NULL, " ");  // func strtok will change the original string!!!!
        int len = strlen(temp);
        ptr[cnt - 1] = malloc(sizeof(char) * len);
        memcpy(ptr[cnt - 1], temp, len - 1);
        ptr[cnt - 1][len] = '\0';
    }

    ptr[cnt] = malloc(sizeof(char) * 5);
    ptr[cnt] = "NULL";
    return ptr;
}*/

void hist_insert(HistQueue *q, char s[]) {
    int len = strlen(s);
    HistNode *tmp = malloc(sizeof(HistNode));
    tmp->ptr = NULL;
    tmp->str = malloc(sizeof(char) * (len + 1));
    strcpy(tmp->str, s);

    if (q->size < 10) {
        q->tail->ptr = tmp;
        q->tail = q->tail->ptr;
        q->size++;
    } else if (q->size == 10) {
        q->tail->ptr = tmp;
        q->tail = q->tail->ptr;
        HistNode *ht = q->head->ptr;
        q->head->ptr = ht->ptr;
        ht->ptr = NULL;
        free(ht);
    }
}

int deal_cmd_operator(char input[], char *cmd[], int num) {
    int cycle_flag = FALSE;
    int cnt = 0;
    int flag_and = FALSE;
    int flag_or = FALSE;
    for (; cnt < num; cnt++) {
        if (strcmp(cmd[cnt], "&&") == 0) {
            flag_and = TRUE;
            break;
        }
        if (strcmp(cmd[cnt], "||") == 0) {
            flag_or = TRUE;
            break;
        }
    }

    // Cope with substring
    char input1[INPUT_MAX];
    char input2[INPUT_MAX];
    char **arg1 = malloc(sizeof(char *) * (cnt + 1));
    char **arg2 = malloc(sizeof(char *) * (num - cnt));
    int arg_num1 = cnt;
    int arg_num2 = num - cnt - 1;
    int index = 0;
    while (input[index] != '&' && input[index] != '|') {
        input1[index] = input[index];
        ++index;
    }
    input1[index] = '\0';

    int k = 0;
    while (input[index] == '&' || input[index] == '|' || input[index] == ' ')
        index++;
    while (input[index] != '\0')
        input2[k++] = input[index++];
    input2[k] = '\0';

    k = 0;
    while (k < cnt) {
        int len = strlen(cmd[k]);
        char *temp = malloc(sizeof(char) * (len + 1));
        strcpy(temp, cmd[k]);
        arg1[k++] = temp;
    }
    arg1[k] = NULL;

    int kk = 0;
    while (++k < num) {
        int len = strlen(cmd[k]);
        char *temp = malloc(sizeof(char) * (len + 1));
        strcpy(temp, cmd[k]);
        arg2[kk++] = temp;
    }
    arg2[kk] = NULL;

    // If symbol '&&' (and)
    if (flag_and) {
        int state;

        if (fork() == 0) {
            int cmd_flag = cmd_judge(arg1[0]);
            state = exec_cmd(cmd_flag, arg_num1, arg1, input1);
            if (!state)
                exit(0);
            else {
                cmd_flag = cmd_judge(arg2[0]);
                state = exec_cmd(cmd_flag, arg_num2, arg2, input2);
                exit(0);
            }
        } else
            wait(&state);

        // If symbol '||' (or)
    } else if (flag_or) {
        int state = FALSE;
        if (fork() == 0) {
            int cmd_flag = cmd_judge(arg1[0]);
            state = exec_cmd(cmd_flag, arg_num1, arg1, input1);
            exit(state);
        } else {
            wait(&state);
            state = WEXITSTATUS(state);
            if (!state) {
                int cmd_flag = cmd_judge(arg2[0]);
                state = exec_cmd(cmd_flag, arg_num2, arg2, input2);
            }
        }
    }
    return cycle_flag;
}

void deal_redirect_operator(int redirect_flag, char input[]) {

    // Input string parse
    if (redirect_flag == 1 || redirect_flag == 2) {
        FILE *fp;
        char filename[INPUT_MAX];
        char subcmd[INPUT_MAX];
        int num;
        int cnt = 0;
        int index = 0;
        while (input[index] == ' ')     // Skip extra spaces
            index++;
        while (input[index] != '>') {   // Record subcommand
            subcmd[cnt++] = input[index++];
        }
        subcmd[cnt++] = '\n';
        subcmd[cnt] = '\0';
        while (input[index] == ' ' || input[index] == '>')
            index++;
        cnt = 0;
        while (input[index] != ' ' && input[index] != '\n')
            filename[cnt++] = input[index++];
        filename[cnt] = '\0';
        char **cmd_ptr = command_parse(subcmd, &num);

        if (redirect_flag == 1)  // Symbol:  >
        {
            fp = fopen(filename, "w");
            if (fork() == 0) {

                if (freopen(filename, "w", stdout) == NULL)     // redirect stdout to file
                    fprintf(stderr, "file redirect error\n");

                int cmd_flag = cmd_judge(cmd_ptr[0]);
                exec_cmd(cmd_flag, num, cmd_ptr, subcmd);
                fclose(stdout);
                exit(0);
            } else {
                wait(NULL);
                fclose(fp);
            }
        } else if (redirect_flag == 2) {     // Symbol:  >>
            if (fork() == 0) {
                index = 0;

                if (freopen(filename, "a+", stdout) == NULL)     // redirect stdout to file
                    fprintf(stderr, "file redirect error\n");

                int cmd_flag = cmd_judge(cmd_ptr[0]);
                exec_cmd(cmd_flag, num, cmd_ptr, subcmd);

                fclose(stdout);
                exit(0);
            } else
                wait(NULL);
        }

    } else if (redirect_flag == 3) {     // Symbol:  |
        char subcmd1[INPUT_MAX];
        char subcmd2[INPUT_MAX];
        //char pipe_buf[INPUT_MAX];
        int num1;
        int num2;
        int index = 0;
        int cnt = 0;
        while (input[index] == ' ')    // Skip extra spaces
            index++;
        while (input[index] != '|')
            subcmd1[cnt++] = input[index++];
        subcmd1[cnt++] = '\n';
        subcmd1[cnt] = '\0';

        while (input[index] == '|' || input[index] == ' ')
            index++;

        cnt = 0;
        while (input[index] != '\0')
            subcmd2[cnt++] = input[index++];
        subcmd2[cnt] = '\0';

        char **arg1 = command_parse(subcmd1, &num1);
        char **arg2 = command_parse(subcmd2, &num2);

        int fd[2];
        if (pipe(fd) < 0) {
            perror("Failed to create pipe\n");
            exit(-1);
        }

        if (fork() == 0) {      // child process exec first command
            close(fd[0]);
            dup2(fileno(stdout), 101);
            dup2(fd[1], fileno(stdout));

            int cmd_flag = cmd_judge(subcmd1);
            exec_cmd(cmd_flag, num1, arg1, subcmd1);
            dup2(101, fileno(stdout));
            close(fd[1]);
            exit(0);
        } else {        // parent process exec second command
			wait(NULL);
            close(fd[1]);
            dup2(fileno(stdin), 100);
            dup2(fd[0], fileno(stdin));
            int cmd_flag = cmd_judge(subcmd2);
            exec_cmd(cmd_flag, num2, arg2, subcmd2);
            dup2(100, fileno(stdin));

        }
    }
}

void deal_background_job(char cmd[]) {
    jobs_cnt = jobs_cnt % JOBS_MAX + 1;
    int job_index = jobs_cnt;
    char temp[INPUT_MAX];
    int pos = 0;
    while (cmd[pos] != '&') {
        temp[pos] = cmd[pos];
        pos++;
    }
    temp[pos++] = '\n';
    temp[pos] = '\0';
    int len = strlen(temp);
    job_table->jobs[jobs_cnt].cmd = malloc(sizeof(char) * (len + 1));
    strcpy(job_table->jobs[jobs_cnt].cmd, temp);
    job_table->job_num++;

    int pid = fork();

    if (pid == 0) {
        int num;
        int cmd_flag = cmd_judge(temp);
        char **arg = command_parse(temp, &num);
        exec_cmd(cmd_flag, num, arg, temp);

        printf("[%d] Done: %s", job_index, temp);
        job_table->jobs[job_index].pid = -1;
        job_table->job_num--;
        free(job_table->jobs[job_index].cmd);
        exit(1);
    } else {
        int state = 0;
        waitpid(pid, &state, WNOHANG);
        job_table->jobs[job_index].pid = pid;
        printf("[%d]\n", job_index);
    }

}

void print_jobs() {
    int cnt = job_table->job_num;
    int pos = 1;
    //printf("job_num:%d\n", job_table.job_num);
    //printf("job[%d]: %s  pid:%d", pos, job_table.jobs[pos].cmd, job_table.jobs[pos].pid);

    while (cnt > 0) {
        if (job_table->jobs[pos].pid > 0) {
            printf("%d: %s", pos, job_table->jobs[pos].cmd);
            //printf("pid is:%d\n", job_table->jobs[pos].pid);
            pos++;
            cnt--;
        } else
            pos++;
    }
}

void kill_job(int job_order) {
    if (job_table->jobs[job_order].pid > 0) {
        if (fork() == 0) {
            //printf("job pid is:%d\n", job_table->jobs[job_order].pid);
            kill(job_table->jobs[job_order].pid, SIGTERM);
            job_table->jobs[job_order].pid = -1;
            free(job_table->jobs[job_order].cmd);
            job_table->job_num--;
            exit(0);
        }else
            wait(NULL);
    } else {
        printf("wshell: no such background job: %d\n", job_order);
    }
}

int cmd_judge(char cmd[]) {
    if (strcmp(cmd, "cd") == 0)
        return 1;
    if (strcmp(cmd, "echo") == 0)
        return 2;
    if (strcmp(cmd, "exit") == 0)
        return 3;
    if (strcmp(cmd, "pwd") == 0)
        return 4;
    if (strcmp(cmd, "history") == 0)
        return 5;
    if (strcmp(cmd, "jobs") == 0)
        return 6;
    if (strcmp(cmd, "kill") == 0)
        return 7;
    else
        return 0;
}

// Exec external or built-in commands
int exec_cmd(int cmd_flag, int cmd_num, char *input_cmd[], char input[]) {
    int exec_flag = FALSE;    // If exec successfully
    switch (cmd_flag) {
        case 0: {
            int status = 1;
            if (fork() == 0) {    // subprocess
                int success = execvp(input_cmd[0], input_cmd);
                if (success == -1)
                    printf("wshell: could not execute command: %s\n", input_cmd[0]);
                exit(1);
            } else {
                wait(&status);
                int res = WEXITSTATUS(status);
                if (res != 1)
                    exec_flag = TRUE;
            }
            break;
        }
        case 1:     // command: cd
            if (cmd_num >= 3) {
                printf("wshell: cd: too many arguments\n");

            } else if (cmd_num == 1) {
                char *home = getenv("HOME");
                strcpy(old_path, buff_path);
                chdir(home);
                exec_flag = TRUE;
            } else if (cmd_num == 2) {
                if (strcmp(input_cmd[1], "-") == 0) {
                    chdir(old_path);
                    strcpy(old_path, buff_path);
                    exec_flag = TRUE;
                } else if (chdir(input_cmd[1]) == -1)
                    printf("wshell: no such directory: %s\n", input_cmd[1]);
                else {
                    strcpy(old_path, buff_path);
                    exec_flag = TRUE;
                }
            }
            break;

        case 2:  // command: echo
        {
            int index = 5;
            char *s = strstr(input, "echo");
            while (s[index] != '\n' && s[index] != '\0')
                printf("%c", s[index++]);
            printf("\n");
            exec_flag = TRUE;
        }
            break;

        case 3:  // command: exit
            exit(0);
            exec_flag = TRUE;
            break;

        case 4:  // command: pwd
            printf("%s\n", buff_path);
            exec_flag = TRUE;
            break;

        case 5:  // command: history
        {
            int i;
            HistNode *n = q->head;
            for (i = 0; i < q->size; i++) {
                n = n->ptr;
                printf("%s", n->str);
            }
            break;
        }

        case 6:  // command: jobs
            print_jobs();
            break;

        case 7:  // command: kill
        {
            int order = strtol(input_cmd[1], NULL, 10);
            kill_job(order);
            break;
        }

        default:
            printf("wshell: could not execute command: %s\n", input_cmd[0]);
    }
    return exec_flag;
}

void prompt_show(char disp[]) {
    printf("%s$ ", disp);
}
