Name: Yihao Cai
WPI Username: ycai5@wpi.edu

As for this project, it is more difficult than the first one and it took me quite a long period than expected to finish it. But I do believe I've learnt a 
lot in dealing with linux process and some low-level design methods during the time. Here I just want to take down something in the experiment.

1. When I try to extract strings from a char array with space delimiter using func strtok(), I didn't realize it would cause changes to the original array
which made me debug the code for a while. It is a very point that we have to be noticed when using this function. 

2. I accidentally found a potential bug using the exec func, which is that once user tries to input the characters 'as' to the shell, it will cause freeze 
rather than throw out the hint: 'xxx': command not found. I think it has something to do with the exec func because I tested it in different versions of shell
and got the same results thereby.

3. For the task 5: background task. I don't know how to use the func waitpid() to make subprocess communicate with the parent by not blocking its thread. So
I tried to implement the mechanism of memory map so that the subprocess could make changes to the memory that is also shared with the parent process and not 
block the main thread in the meanwhile.

Anyhow my code could meet the requirements of homework but I'm pretty sure there're still many bugs in it. I'll try to make it perfect as much as possible
during leisure time so that it could work like a real shell under ubuntu environment.