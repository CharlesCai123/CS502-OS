#!/bin/bash

sleep 1
echo "Hello from the script!"
