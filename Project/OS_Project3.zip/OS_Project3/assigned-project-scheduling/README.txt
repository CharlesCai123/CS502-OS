Name: Yihao Cai
WPI Username: ycai5@wpi.edu

This project is quite interesting because it is about cpu schedule algorithm implementation. To be honest, it had taken me more time than expected to get all of them 
finished, and the code I wrote is a bit redundant. Maybe it indicates that I don't have a brief and instinct understanding to these three algorithms. And that's the part
where I have to make some progress myself. 

For the details of implementation, it is quite simple to finish the first two parts shown as FCFS and SJF. However, problems came out as I stepped into part three. The thing
is that, to my best knowledge, Round-robin goes like a queue where many programs are put into the end as they arrive. Every time for a time quantum, the queue will get the 
task in the front of queue and send it to cpu. Additionally, the one whose required burst time exceeds the time quantum will also be put back to the end of queue after its 
execution. But truthfully that doesn't correspond to the HW requirement. After consulting Prof Guo, I noticed that RR would always put the newly-arrived job into the queue 
instead of putting back the one that has just already been executed by cpu. In this way, the starvation would not happen once there exist many jobs in the queue. And finally
I am able to get the right results thereby.

All in all, I don't think this HW is much easier than the previous one. Maybe it is because I got weak in algorithm. But anyhow I realize this point and of course I will make 
it strong on futher courses.  