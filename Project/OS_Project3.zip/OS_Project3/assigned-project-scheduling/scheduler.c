#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define TRUE 1
#define FALSE 0
#define MAX 10000000
#define COL_MAX 10
#define JOB_NUM_MAX 1000000

//const char **schedule_policy = {"FIFO", "SJF", "RR"};
int job_id = 0;

/********* Struct Definition For Job *********/
typedef struct job {
    int id;               // Job id
    int length;           // Time needed to be done
    _Bool resp_flag;      // Response Flag
    int arrival_time;     // Arrival Time
    int exec_time;        // Burst Time
    int resp_time;        // Response Time
    int turnaround_time;  // Turnaround Time
    int wait_time;        // Wait Time
    struct job *last;     // Point to last elem
    struct job *next;     // Point to next elem
} Job;

typedef struct {
    int length;
    Job *head;
} JobLinkTable;

typedef struct {
    int len;
    Job *job_element;
} JobSeqTable;

typedef struct {
    _Bool analysis_flag;
    int policy;
    char *workload_file;
    double time_slice;
} InputInfo;

typedef struct {
    int length;
    Job *front;
    Job *end;
} JobQueue;

/***************** Func ******************/
InputInfo *InputParse(char **ch);

JobLinkTable *JobLInkInfoParse(char *filename);

JobSeqTable *JobSeqInfoParse(char *filename);

void SeqTableSort(JobSeqTable *table, int i, int j);

void SeqTableInit(JobSeqTable *table);

void SeqElementSwap(JobSeqTable *job_seq_table, int i, int j);

Job *NodeDeepCopy(JobSeqTable *table, int order);

void QueueAdd(JobQueue *q, Job *elem);

int FindJobFromTable(JobSeqTable *table, Job *job);

Job *QueueDelete(JobQueue *q, Job *elem);

void FIFO(JobLinkTable *job_table);

void SJF(JobSeqTable *job_table);

void RoundRobin(JobSeqTable *table, int time_slot);

/***************** Main Thread ******************/
int main(int argc, char **argv) {
    InputInfo *input;
    JobLinkTable *job_link_table;
    JobSeqTable *job_seq_table;

    if (argc == 5) {
        input = InputParse(argv);
    }

    if (input->policy == 0) {   // FIFO
        job_link_table = JobLInkInfoParse(input->workload_file);
        FIFO(job_link_table);
        printf("Execution trace with FIFO:\n");
        Job *index = job_link_table->head;
        int i = 0;
        for (; i < job_link_table->length; i++) {
            index = index->next;
            printf("t=%d: [Job %d] arrived at [%d], ran for: [%d]\n", index->exec_time, index->id, index->arrival_time,
                   index->length);
        }
        printf("End of execution with FIFO.\n");

        if (input->analysis_flag == TRUE) {     // Analysis Flag
            double resp_sum = 0;
            double turnaround_sum = 0;
            double wait_sum = 0;
            printf("Begin analyzing FIFO:\n");
            Job *index = job_link_table->head->next;
            i = 0;
            while (index != NULL) {

                resp_sum += index->resp_time;
                turnaround_sum += index->turnaround_time;
                wait_sum += index->wait_time;
                printf("Job %d -- Response time: %d  Turnaround: %d  Wait: %d\n", index->id, index->resp_time, index->
                        turnaround_time, index->wait_time);
                i++;
                index = index->next;
            }

            double resp_avg = resp_sum / i;
            double turnaround_avg = turnaround_sum / i;
            double wait_avg = wait_sum / i;
            printf("Average -- Response: %.2lf  Turnaround %.2lf  Wait %.2lf\n", resp_avg, turnaround_avg, wait_avg);
            printf("End analyzing FIFO.\n");
        }


    } else if (input->policy == 1) {     // SJF
        job_seq_table = JobSeqInfoParse(input->workload_file);
        SJF(job_seq_table);
        printf("Execution trace with SJF:\n");

        int i = 0;
        for (; i < job_seq_table->len; i++) {
            Job temp = job_seq_table->job_element[i];
            printf("t=%d: [Job %d] arrived at [%d], ran for: [%d]\n", temp.exec_time, temp.id, temp.arrival_time,
                   temp.length);
        }
        printf("End of execution with SJF.\n");

        if (input->analysis_flag == TRUE) {     // Analysis Flag
            double resp_sum = 0;
            double turnaround_sum = 0;
            double wait_sum = 0;
            printf("Begin analyzing SJF:\n");
            for (i = 0; i < job_seq_table->len; i++) {
                int index = 0;

                while (job_seq_table->job_element[index].id != i)
                    index++;
                Job temp = job_seq_table->job_element[index];

                resp_sum += temp.resp_time;
                turnaround_sum += temp.turnaround_time;
                wait_sum += temp.wait_time;
                printf("Job %d -- Response time: %d  Turnaround: %d  Wait: %d\n", temp.id, temp.resp_time, temp
                        .turnaround_time, temp.wait_time);
            }
            double resp_avg = resp_sum / i;
            double turnaround_avg = turnaround_sum / i;
            double wait_avg = wait_sum / i;
            printf("Average -- Response: %.2lf  Turnaround %.2lf  Wait %.2lf\n", resp_avg, turnaround_avg, wait_avg);
            printf("End analyzing SJF.\n");
        }
    } else if (input->policy == 2) {       // Round-robin
        job_seq_table = JobSeqInfoParse(input->workload_file);
        printf("Execution trace with RR:\n");
        RoundRobin(job_seq_table, input->time_slice);
        printf("End of execution with RR.\n");

        if (input->analysis_flag == TRUE) {     // Analysis Flag
            double resp_sum = 0;
            double turnaround_sum = 0;
            double wait_sum = 0;
            printf("Begin analyzing RR:\n");
            int i = 0;
            Job *temp = job_seq_table->job_element;
            for (; i < job_seq_table->len; i++) {
                printf("Job %d -- Response time: %d  Turnaround: %d  Wait: %d\n", temp[i].id, temp[i].resp_time, temp[i].turnaround_time, temp[i].wait_time);
                resp_sum += temp[i].resp_time;
                turnaround_sum += temp[i].turnaround_time;
                wait_sum += temp[i].wait_time;
            }
            double resp_avg = resp_sum / i;
            double turnaround_avg = turnaround_sum / i;
            double wait_avg = wait_sum / i;
            printf("Average -- Response: %.2lf  Turnaround %.2lf  Wait %.2lf\n", resp_avg, turnaround_avg, wait_avg);
            printf("End analyzing RR.\n");
        }
    }
}

// Parse input parameters
InputInfo *InputParse(char **ch) {
    InputInfo *info = malloc(sizeof(InputInfo));

    // Analysis Flag
    if (strcmp(ch[1], "0") == 0) {
        info->analysis_flag = FALSE;
    } else if (strcmp(ch[1], "1") == 0) {
        info->analysis_flag = TRUE;
    }

    // Schedule Policy
    if (strcmp(ch[2], "FIFO") == 0) {
        info->policy = 0;
    } else if (strcmp(ch[2], "SJF") == 0) {
        info->policy = 1;
    } else if (strcmp(ch[2], "RR") == 0) {
        info->policy = 2;
    }

    // Input FileName
    int len = strlen(ch[3]);
    info->workload_file = malloc(len + 1);
    strcpy(info->workload_file, ch[3]);

    // Time slice of RR
    char *ptr;
    info->time_slice = strtod(ch[4], &ptr);

    return info;
}

JobLinkTable *JobLInkInfoParse(char *filename) {
    FILE *fp = NULL;
    char *line, *record;
    char buffer[COL_MAX];

    //Job Link Table Initialization
    JobLinkTable *job_table = malloc(sizeof(JobLinkTable));
    job_table->length = 0;
    job_table->head = malloc(sizeof(Job));
    job_table->head->length = MAX;
    job_table->head->next = NULL;
    job_table->head->last = NULL;

    Job *index = job_table->head;  // Used for incrementing the job data

    if ((fp = fopen(filename, "r")) != NULL) {
        while ((line = fgets(buffer, sizeof(buffer), fp)) != NULL) {
            record = strtok(line, ",");
            job_table->length++;
            Job *temp = malloc(sizeof(Job));
            temp->arrival_time = atoi(record);
            temp->id = job_id;
            temp->exec_time = 0;
            job_id++;
            temp->next = NULL;
            index->next = temp;
            temp->last = index;
            index = index->next;

            record = strtok(NULL, ",");
            temp->length = atoi(record);
        }
        fclose(fp);
    }
    return job_table;
}

JobSeqTable *JobSeqInfoParse(char *filename) {
    FILE *fp = NULL;
    char *line, *record;
    char buffer[COL_MAX];

    //Job Sequence Table Initialization
    JobSeqTable *job_table = malloc(sizeof(JobSeqTable));
    job_table->len = 0;
    job_table->job_element = malloc(sizeof(Job) * JOB_NUM_MAX);

    if ((fp = fopen(filename, "r")) != NULL) {
        while ((line = fgets(buffer, sizeof(buffer), fp)) != NULL) {
            record = strtok(line, ",");

            job_table->job_element[job_table->len].id = job_id;
            job_table->job_element[job_table->len].arrival_time = atoi(record);
            job_table->job_element[job_table->len].exec_time = 0;

            record = strtok(NULL, ",");

            job_table->job_element[job_table->len].length = atoi(record);

            job_table->len++;
            job_id++;
        }
        fclose(fp);
    }
    return job_table;
}

void SeqElementSwap(JobSeqTable *job_seq_table, int i, int j) {
    Job temp;
    temp.id = job_seq_table->job_element[i].id;
    temp.length = job_seq_table->job_element[i].length;
    temp.exec_time = job_seq_table->job_element[i].exec_time;
    temp.arrival_time = job_seq_table->job_element[i].arrival_time;

    job_seq_table->job_element[i].id = job_seq_table->job_element[j].id;
    job_seq_table->job_element[i].length = job_seq_table->job_element[j].length;
    job_seq_table->job_element[i].exec_time = job_seq_table->job_element[j].exec_time;
    job_seq_table->job_element[i].arrival_time = job_seq_table->job_element[j].arrival_time;

    job_seq_table->job_element[j].id = temp.id;
    job_seq_table->job_element[j].length = temp.length;
    job_seq_table->job_element[j].exec_time = temp.exec_time;
    job_seq_table->job_element[j].arrival_time = temp.arrival_time;

}

void SeqTableSort(JobSeqTable *table, int i, int j) {
    for (; i <= j; i++) {
        int k = i;
        int temp = k;
        for (; k <= j; k++) {
            if (table->job_element[k].length < table->job_element[temp].length) {
                temp = k;
            } else if (table->job_element[k].length == table->job_element[temp].length &&
                       table->job_element[k].arrival_time < table->job_element[temp].arrival_time) {
                temp = k;
            } else if (table->job_element[k].length == table->job_element[temp].length
                       && table->job_element[k].arrival_time == table->job_element[temp].arrival_time &&
                       table->job_element[k].id < table->job_element[temp].id) {
                temp = k;
            }
        }
        SeqElementSwap(table, i, temp);
    }
}

void SeqTableInit(JobSeqTable *table) {
    int len = table->len;
    int index = 1;
    Job elem = table->job_element[0];
    while (index < len && elem.arrival_time == table->job_element[index].arrival_time) {
        index++;
    }
    SeqTableSort(table, 0, index - 1);
}

// FIFO Algorithm
void FIFO(JobLinkTable *job_table) {
    Job *index = job_table->head->next;
    int t = 0;
    while (index != NULL) {
        index->exec_time = t;
        index->resp_time = t - index->arrival_time;     // Response Time
        index->turnaround_time = t + index->length - index->arrival_time;       // Turnaround Time
        index->wait_time = index->resp_time;    // Wait Time

        t += index->length;
        index = index->next;
    }
}

// SJF Algorithm
void SJF(JobSeqTable *job_seq_table) {

    int i = 0;
    int len = job_seq_table->len;
    Job *table = job_seq_table->job_element;
    SeqTableInit(job_seq_table);

    while (i < len) {
        int index = i;
        int end_time = table[i].arrival_time + table[i].length;
        if (end_time > table[len - 1].arrival_time) {
            SeqTableSort(job_seq_table, i + 1, len - 1);
            break;
        } else {
            while (table[index].arrival_time <= end_time) {
                index++;
            }
            SeqTableSort(job_seq_table, i + 1, index - 1);
        }
        i++;
    }

    int t = 0;
    for (i = 0; i < job_seq_table->len; i++) {
        job_seq_table->job_element[i].exec_time = t;    // Present Time
        job_seq_table->job_element[i].resp_time = t - job_seq_table->job_element[i].arrival_time;   // Response Time
        job_seq_table->job_element[i].turnaround_time = t + job_seq_table->job_element[i]
                .length - job_seq_table->job_element[i].arrival_time;     // Turnaround Time
        job_seq_table->job_element[i].wait_time = job_seq_table->job_element[i].resp_time;  // Wait Time

        if (i < len - 1 && job_seq_table->job_element[i + 1].arrival_time > job_seq_table->job_element[i].exec_time +
                                                                            job_seq_table->job_element[i].length)
            t = job_seq_table->job_element[i + 1].arrival_time;
        else {
            t += job_seq_table->job_element[i].length;
        }

    }
}

// Add element to end of queue
void QueueAdd(JobQueue *q, Job *elem) {
    if (q->length == 0) {
        q->front = q->end = elem;
        elem->next = elem->last = NULL;
    } else {
        q->end->next = elem;
        elem->last = q->end;
        q->end = q->end->next;
        q->end->next = NULL;
    }
    q->length++;
}

Job *QueueDelete(JobQueue *q, Job *elem) {
    Job *index = NULL;
    if (q->length == 1) {
        q->front = q->end = NULL;
        free(elem);
    } else {
        if (elem == q->end) {
            Job *temp = q->end->last;
            temp->next = NULL;
            free(q->end);
            q->end = temp;
        } else if (elem == q->front) {
            Job *temp = q->front;
            q->front = q->front->next;
            temp->next = NULL;
            free(temp);
            index = q->front;
        } else {
            Job *pre = elem->last;
            Job *after = elem->next;
            elem->next = elem->last = NULL;
            pre->next = after;
            after->last = pre;
            free(elem);
            index = after;
        }
    }

    q->length--;
    return index;
}

// Deepcopy a node from a sequence table
Job *NodeDeepCopy(JobSeqTable *table, int order) {
    Job *temp = malloc(sizeof(Job));
    temp->id = table->job_element[order].id;
    temp->length = table->job_element[order].length;
    temp->resp_flag = table->job_element[order].resp_flag;
    temp->exec_time = table->job_element[order].exec_time;
    temp->resp_time = table->job_element[order].resp_time;
    temp->wait_time = table->job_element[order].wait_time;
    temp->arrival_time = table->job_element[order].arrival_time;
    temp->turnaround_time = table->job_element[order].turnaround_time;

    return temp;
}

int FindJobFromTable(JobSeqTable *table, Job *job) {
    int i = 0;
    for (; i < table->len; i++) {
        if (table->job_element[i].id == job->id)
            return i;
    }
    return -1;
}

// RR Algorithm
void RoundRobin(JobSeqTable *table, int time_slot) {
    int index = 0;
    int t = 0;
    JobQueue *queue = malloc(sizeof(JobQueue));
    queue->length = 0;
    Job *temp = NodeDeepCopy(table, index);
    table->job_element[index].resp_time = t;
    index++;
    QueueAdd(queue, temp);

    Job *currJob = queue->front;        // Index ptr for jobs in queue

    while (index < table->len || queue->length != 0) {
        // Queue becomes empty
        if (queue->length == 0) {
            t = table->job_element[index].arrival_time;
            Job *temp = NodeDeepCopy(table, index);
            table->job_element[index].resp_time = 0;

            QueueAdd(queue, temp);
            index++;
            currJob = queue->front;
            continue;
        }

        if (currJob != NULL) {

            if (currJob->length < time_slot) {
                // Record Response Time
                if (currJob->resp_flag == FALSE) {
                    currJob->resp_time = t - currJob->arrival_time;
                    currJob->resp_flag = TRUE;
                }
                printf("t=%d: [Job %d] arrived at [%d], ran for: [%d]\n", t, currJob->id, currJob->arrival_time, currJob->length);
                t += currJob->length;
                // currJob->exec_time += currJob->length;      // Record Burst Time

                while (index < table->len && t >= table->job_element[index].arrival_time) {
                    Job *temp = NodeDeepCopy(table, index++);
                    QueueAdd(queue, temp);
                }

                int order = FindJobFromTable(table, currJob);
                table->job_element[order].resp_time = currJob->resp_time;   // Save Response Time
                table->job_element[order].turnaround_time = t - currJob->arrival_time;  // Record Turnaround Time
                table->job_element[order].wait_time = table->job_element[order].turnaround_time - table->job_element[order].length;    // Record Wait Time

                currJob = QueueDelete(queue, currJob);

            } else {
                // Record Response Time
                if (currJob->resp_flag == FALSE) {
                    currJob->resp_time = t - currJob->arrival_time;
                    currJob->resp_flag = TRUE;
                }
                printf("t=%d: [Job %d] arrived at [%d], ran for: [%d]\n", t, currJob->id, currJob->arrival_time,
                       time_slot);
                t += time_slot;
                currJob->length -= time_slot;


                while (index < table->len && t >= table->job_element[index].arrival_time) {
                    Job *temp = NodeDeepCopy(table, index++);
                    QueueAdd(queue, temp);
                }

                if (currJob->length == 0) {
                    int order = FindJobFromTable(table, currJob);
                    table->job_element[order].resp_time = currJob->resp_time;   // Save Response Time
                    table->job_element[order].turnaround_time = t - currJob->arrival_time;  // Record Turnaround Time
                    table->job_element[order].wait_time = table->job_element[order].turnaround_time - table->job_element[order].length;    // Record Wait Time

                    currJob = QueueDelete(queue, currJob);
                } else
                    currJob = currJob->next;
            }
        } else {
            currJob = queue->front;
        }
    }
}