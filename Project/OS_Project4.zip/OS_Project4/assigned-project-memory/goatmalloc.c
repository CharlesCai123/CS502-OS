//Place code here.
#include <stdio.h>
#include <stdlib.h>
#include <linux/stddef.h>
#include <unistd.h>
#include "goatmalloc.h"
#include <sys/mman.h>
#include <fcntl.h>

#define TRUE 1
#define FALSE 0

void *arena_start;
void *arena_free_ptr;
int arena_size = 0;
int chunk_num = 0;
int curr_node = 1;
node_t *header = NULL;
node_t *currNodeIndex = NULL;      // An interesting thing -- as I tried to name it as Index, a warranty comes out showing index is a built-in function, for which I have to change the name

int statusno;

int init(size_t size) {
    printf("Initializing arena :\n");
    if (size + MAX_ARENA_SIZE >= 0 && size + MAX_ARENA_SIZE < MAX_ARENA_SIZE) {
        return ERR_BAD_ARGUMENTS;
    }
    if (size == 0)
        return 0;
    if (size > MAX_ARENA_SIZE) {
        printf("...requested size %zu bytes\n", size);
        printf("...error: requested size larger than MAX_ARENA_SIZE (2147483647)");
        return ERR_OUT_OF_MEMORY;
    }
    int page_size = getpagesize();
    printf("...requested size %zu bytes\n", size);
    printf("...pagesize is %d bytes\n", page_size);
    printf("... adjusting size with page boundaries\n");

    int num = size / page_size;
    int remainder = size % page_size;

    if (remainder != 0)
        num += 1;
    chunk_num = num;

    printf("mapping arena with mmap ()\n");
    int fd = open("/dev/zero", O_RDWR);
    arena_start = mmap(NULL, num * page_size, PROT_READ | PROT_WRITE, MAP_PRIVATE, fd, 0);
    if (arena_start == MAP_FAILED) {
        return ERR_UNINITIALIZED;
    }
    arena_size = num * page_size;

    printf("... adjusted size is %d bytes\n", arena_size);
    printf("... arena starts at %p\n", arena_start);
    printf("... arena ends at %p\n", arena_start + arena_size);

    printf("initializing header for initial free chunk\n");
    currNodeIndex = header = (node_t *) arena_start;
    header->size = page_size - sizeof(node_t);
    header->is_free = TRUE;
    header->fwd = NULL;
    header->bwd = NULL;
    //arena_free_ptr = (void *) header + sizeof(node_t);

/*    int i;
    node_t *temp = header->bwd;
    node_t *pre = header;
    for (i = 1; i < num; i++) {
        temp->size = page_size - sizeof(node_t);
        temp->is_free = TRUE;
        temp->fwd = pre;
        if (i == num - 1)
            temp->bwd = NULL;
        else
            temp->bwd = (node_t *) arena_start + (i + 1) * page_size;
        pre->bwd = temp;
        pre = temp;
        temp = temp->bwd;
    }
    temp = pre = NULL;*/
    //printf("... header size is %lu bytes\n",sizeof(header));
    return arena_size;
}

int destroy() {
    printf("Destroying Arena :\n");
    printf("unmapping arena with munmap ()\n");
    if (arena_size == 0)
        return ERR_UNINITIALIZED;
    int result = munmap(arena_start, arena_size);
    header = NULL;
    arena_size = 0;
    chunk_num = 0;
    return result;
}

void *walloc(size_t size) {
    void *ptr = NULL;

    // Find the existing free chunk with enough space to allocate
    node_t *index = header;
    while (index != currNodeIndex) {
        if (index->is_free == TRUE && index->size >= size) {
            index->is_free = FALSE;
            ptr = (void *) index + sizeof(node_t);
            return ptr;
        }
        index = index->fwd;
    }

    // If the existing free chunks cannot be found
    if (arena_size == 0) {
        statusno = ERR_UNINITIALIZED;
        return ptr;
    }
    if (currNodeIndex->is_free == FALSE || size > currNodeIndex->size) {
        statusno = ERR_OUT_OF_MEMORY;
        return ptr;
    }
    ptr = (void *) currNodeIndex + sizeof(node_t);

    if (currNodeIndex->is_free == TRUE && currNodeIndex->size == size) {
        //currNodeIndex->size = 0;
        currNodeIndex->is_free = FALSE;
        currNodeIndex->fwd = NULL;
        return ptr;
    }
    if (currNodeIndex->is_free == TRUE && currNodeIndex->size - size < sizeof(node_t) + 1) {
        //currNodeIndex->size -= size;
        currNodeIndex->is_free = FALSE;
        currNodeIndex->fwd = NULL;
        return ptr;
    }

    int rest = currNodeIndex->size;
    currNodeIndex->size = size;
    currNodeIndex->is_free = FALSE;
    currNodeIndex->fwd = (void *) currNodeIndex + sizeof(node_t) + size;

    node_t *next = currNodeIndex->fwd;
    next->size = rest - size - sizeof(node_t);
    next->is_free = TRUE;
    next->bwd = currNodeIndex;
    next->fwd = NULL;
    currNodeIndex = next;

/*    while (size > 0) {
        int rest_chunk = currNodeIndex->size;
        if (size < rest_chunk) {
            arena_free_ptr += size;
            break;
        } else if (size == rest_chunk) {
            currNodeIndex->size = 0;
            currNodeIndex->is_free = FALSE;
            if (currNodeIndex->bwd == NULL) {
                arena_free_ptr = NULL;
            } else {
                arena_free_ptr = (void *) currNodeIndex->bwd + sizeof(node_t);
                curr_node++;
            }
            currNodeIndex = currNodeIndex->bwd;
            break;
        } else {
            size -= rest_chunk;
            currNodeIndex->size = 0;
            currNodeIndex->is_free = FALSE;
            currNodeIndex = currNodeIndex->bwd;
            if (currNodeIndex != NULL) {
                curr_node++;
                arena_free_ptr = (void *) currNodeIndex->bwd + sizeof(node_t);
            } else {
                arena_free_ptr = NULL;
                break;
            }
        }
    }*/
    return ptr;
}

void wfree(void *ptr) {
    node_t *p = ptr - sizeof(node_t);
    p->is_free = TRUE;
    // First Node
    if (p->bwd == NULL && p->fwd != NULL) {
        if (p->fwd->is_free == TRUE) {
            node_t *temp = p->fwd;
            p->size += sizeof(node_t) + temp->size;
            p->fwd = temp->fwd;
            if(temp->fwd!=NULL)
                temp->fwd->bwd = p;
            temp->fwd = temp->bwd = NULL;
        }
        return;
    }
    // Last Node
    if (p->fwd == NULL && p->bwd != NULL) {
        if (p->bwd->is_free == TRUE) {
            node_t *temp = p->bwd;
            temp->size += sizeof(node_t) + p->size;
            temp->fwd = p->fwd;
            p->fwd = p->bwd = NULL;
        }
        return;
    }
    // Any Middle Node
    if (p->fwd != NULL && p->bwd != NULL) {
        // Left && Right Node both free
        if (p->fwd->is_free == TRUE && p->bwd->is_free == TRUE) {
            node_t *temp = p->bwd;
            node_t *temp2 = p->fwd;

            temp->size += 2 * sizeof(node_t) + p->size + p->fwd->size;
            temp->fwd = temp2->fwd;
            if (temp2->fwd != NULL)
                temp2->fwd->bwd = temp;

            p->bwd = p->fwd = temp2->fwd = temp2->bwd = NULL;
            return;
        }
        // Only Right Node free
        if (p->fwd->is_free == TRUE && p->bwd->is_free == FALSE) {
            node_t *temp = p->fwd;
            p->size += sizeof(node_t) + temp->size;
            p->fwd = temp->fwd;
            if(temp->fwd!=NULL)
                temp->fwd->bwd = p;
            temp->fwd = temp->bwd = NULL;
            return;
        }
        // Only Left Node free
        if (p->fwd->is_free == FALSE && p->bwd->is_free == TRUE) {
            node_t *temp = p->bwd;
            temp->size += sizeof(node_t) + p->size;
            temp->fwd = p->fwd;
            p->fwd->bwd = temp;
            p->fwd = p->bwd = NULL;
            return;
        }
    }

}