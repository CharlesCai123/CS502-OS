Name: Yihao Cai
WPI Username: ycai5@wpi.edu

Project for this time is quite simple, which is mostly about operations for link table structure. To be honest, I'd expect some more complex structures about
memory related algorithms and I think in this way it works better for us to understand the memory allocation mechanism. Besides, it took me only short time 
to implement the code, but quite a long time to fully understand the requirement and also to think up the profile of the design. I'd suggest that the sylabus 
of the HW firstly gives out a sketch instead of illustrating the concepts one by one at each separate part. 

And there's something interesting I encountered during coding which is that as I tried to define a global variant with name 'index', the compiler would always
throw out the warning that it is a built-in function and require me to change the name for it. Looking through on the internet, it is said that it may be caused
by the fact that compiler has a built-in function with the name 'index' so it doesn't allow the same name to be used as global variant. I don't know whether it
is right exactly, but it seems quite interesting!
