CS502: Project 6 Goat File System
==================================

Note, this document includes a number of design questions that can help your implementation. We highly recommend that you answer each design question **before** attempting the corresponding implementation.
These questions will help you design and plan your implementation and guide you towards the resources you need.
Finally, if you are unsure how to start the project, we recommend you visit office hours for some guidance on these questions before attempting to implement this project.


Team members
-----------------
Yihao Cai (ycai5@wpi.edu)

Design Questions
------------------

1. When implementing the `debug()` function, you will need to load the file system via the emulated disk and retrieve the information for superblock and inodes.
1.1 How will you read the superblock?
1.2 How will you traverse all the inodes?
1.3 How will you determine all the information related to an inode?
1.4 How will you determine all the blocks related to an inode?

Brief Response:

1.1 I use wread() to save content of first block into a string buffer and parse the first 32 bytes with 8 bytes as a group per time.
    Each time I parse the 8 bytes string, I reverse them (due to big-little endian) and convert to a long integer using function strtol().
    In this way, I am able to parse the four fields of superblock.

1.2 By judging the first valid field of each inode with address 32*(inode_order)

1.3 Because an inode is 32 bytes, each field (altogether 8) is of 4 bytes. Thus, I just parse them one by one with 4 bytes for
    each field. If indirect field is not empty, program would go to the block accordingly and continue its parse until it meets
    0 for every 4-byte field.

1.4 I get access to them by counting the address offset BLOCKSIZE*block_num

---

2. When implementing the `format()` function, you will need to write the superblock and clear the remaining blocks in the file system.

2.1 What should happen if the file system is already mounted?
2.2 What information must be written into the superblock?
2.3 How would you clear all the remaining blocks?

Brief Response:

2.1 Failed

2.2 Four fields (MagicNumber, block, inodeblock, inode)

2.3 By writing NULL character to the blocks

---

3. When implementing the `mount()` function, you will need to prepare a filesystem for use by reading the superblock and allocating the free block bitmap.

3.1 What should happen if the file system is already mounted?
3.2 What sanity checks must you perform before building up the free block bitmaps?
3.3 How will you determine which blocks are free?

Brief Response:

3.1 Failed

3.2 Check whether this file system has already been mounted

3.3 Using bitmap

---

4. To implement `create()`, you will need to locate a free inode and save a new inode into the inode table.

4.1 How will you locate a free inode?
4.2 What information would you see in a new inode?
4.3 How will you record this new inode?

Brief Response:

4.1 By using index pointer and bitmap

4.2 Valid field is set to be 1 but other fields remain null

4.3 Writing inode information to file on disk and updating bitmap

---

5. To implement `remove()`, you will need to locate the inode and then free its associated blocks.

5.1 How will you determine if the specified inode is valid?
5.2 How will you free the direct blocks?
5.3 How will you free the indirect blocks?
5.4 How will you update the inode table?

Brief Response:

5.1 By reading the inode blocks where the inode is and extract info about this specific inode

5.2 By setting value to 0 and update the bitmap

5.3 Same as 5.2

5.4 Writing back the modified inode block buff string

---

6. To implement `stat()`, you will need to locate the inode and return its size.

6.1 How will you determine if the specified inode is valid?
6.2 How will you determine the inode's size?

Brief Response:

6.1 By inode bitmap

6.2 Extract inode info from inode blocks

---

7. To implement `read()`, you will need to locate the inode and copy data from appropriate blocks to the user-specified data buffer.

7.1  How will you determine if the specified inode is valid?
7.2  How will you determine which block to read from?
7.3  How will you handle the offset?
7.4  How will you copy from a block to the data buffer?

Brief Response:

7.1 From inode bitmap

7.2 Use chunk_order = offset / BLOCK_SIZE to get the exact chunk order of direct/indirect of the inode, and read the related
    block according to field of inode.Direct and inode.Indirect

7.3 Use start_addr = offset % BLOCK_SIZE to decide where to start reading in each block

7.4 Continue read data from block to data buffer until:
    1). reach the end of block;
    2). reach the total length of character to be read;
    3). identify a null character;

---

8. To implement `write()`, you will need to locate the inode and copy data the user-specified data buffer to data blocks in the file system.

8.1  How will you determine if the specified inode is valid?
8.2  How will you determine which block to write to?
8.3  How will you handle the offset?
8.4  How will you know if you need a new block?
8.5  How will you manage allocating a new block if you need another one?
8.6  How will you copy from a block to the data buffer?
8.7  How will you update the inode?

Brief Response:

8.1 From inode bitmap

8.2 Use chunk_order = offset / BLOCK_SIZE to get the exact chunk order of direct/indirect of the inode, and write to the related
    block according to field of inode.Direct and inode.Indirect

8.3 Use start_addr = offset % BLOCK_SIZE to decide where to start writing in each block

8.4 When reach the end of a block but there's still characters to be written remaining

8.5 According to the block bitmap pointer. Assign blocks if there's still free block remaining, and stop writing if no more space

8.6 Use wread() function provided

8.7 Write inode info back to inode block once finish data writing process to disk each time

---


Errata
------

Describe any known errors, bugs, or deviations from the requirements.

---

Overall, this is a great assignment to help deep understand the mechanism of file system as to how the inode interacts with
the blocks and how to manage data storage when dealing with external data read/write. The first important point is to hold
a clear understanding of what you need to do for designing a goat file system. And then for the inode create/remove/stat part,
my file I/O times differ from the given example in shell script in that mine is less than it, which proves a bit more optimized
I/O performance in the file system I designed. Actually I don't think I ran into any problems until I started to solving test
cases about data reading and writing. It is hard to debug somehow which consumed me a lot of time figuring out whether my code
architecture is in the right way. Finally, I solve it by examining each variable and expected data in memory step by step.
Everything goes well though the debug procedure is a bit torturing.

From it, I found it is of importance to mark every variable name clearly so that you can know what it represents for an abstract
object at first glance, especially if it will be used for multiple times. I got many errors and bugs in file read/write test cases
just because I set many ambiguous variables which are used improperly at each certain situation. Anyhow, this practice helps
me gain more experience in file system design, which indeed makes sense for the course.

(Optional) Additional Test Cases
--------------------------------

Describe any new test cases that you developed.

