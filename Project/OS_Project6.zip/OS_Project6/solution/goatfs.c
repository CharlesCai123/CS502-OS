// Goat File System Implementation
// #include <assert.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>

// #include <math.h>
// #include<sys/types.h>

#include "disk.h"
#include "goatfs.h"

/******* Bitmap for inode and block *******/
_Bool *_inode_bitmap = NULL;
_Bool *_block_bitmap = NULL;

int _inode_bitmap_ptr = -1;
int _block_bitmap_ptr = -1;
/*********************************************/

Block *superblock_ptr;

SuperBlock SuperBlockParse(char *data);
Inode InodeSoleParse(char *inode_block, int index);
void SuperBlockPrint(SuperBlock superB);
void InodeInfoPrint(Inode inode);
void InodeParseToBitmap(Inode inode);
int locate_free_ptr(_Bool *bitmap, int size);

// Parse Binary (Hex) String with length from index position of data to long integer
long BinaryStringParse(char *data, int index, int length);
// Write hex form of srcNumber with 4 bytes length from index position of data
void BinaryStringWrite(char *data, int index, int srcNumber);

void print_bitmap(_Bool *ptr, int length);
void InodeWrite(Inode inode, int index);
void BlockInit(int blockNum);

void debug() {
    char buff[BLOCK_SIZE];

    // Read first block (SuperBlock) and parse
    wread(0, buff);
    SuperBlock superB = SuperBlockParse(buff);

    // Print SuperBlock Info
    SuperBlockPrint(superB);

    // Print INode Info
    int i;
    for (i = 1; i <= superB.InodeBlocks; i++) {
        wread(i, buff);
        int j;
        for (j = 0; j < INODES_PER_BLOCK; j++) {
            Inode temp_inode = InodeSoleParse(buff, j);
            if (temp_inode.Valid == 0)
                continue;
            printf("Inode %d:\n", j);
            InodeInfoPrint(temp_inode);
        }
    }
}

bool format() {
    // Return False if mounted
    if (_block_bitmap_ptr != -1 && _inode_bitmap_ptr != -1)
        return false;

    // Format SuperBlock
    float res = _disk->Blocks * 0.1;
    int inodeNum = (int) res;
    if (inodeNum < res)
        inodeNum++;
    char sbBuf[BLOCK_SIZE] = {'\0'};
    BinaryStringWrite(sbBuf, 0, MAGIC_NUMBER);
    BinaryStringWrite(sbBuf, 4, _disk->Blocks);
    BinaryStringWrite(sbBuf, 8, inodeNum);
    BinaryStringWrite(sbBuf, 12, inodeNum * INODES_PER_BLOCK);
    wwrite(0, sbBuf);

    // Format Remaining Blocks
    int i;
    for (i = 1; i < _disk->Blocks; i++) {
        char buf[BLOCK_SIZE] = {'\0'};
        wwrite(i, buf);
    }
    return true;
}

int mount() {

    // Mount error if already mounted
    if (_block_bitmap_ptr != -1 && _inode_bitmap_ptr != -1)
        return ERR_ALREADY_MOUNTED;

    // Get info of superblock
    char buff[BLOCK_SIZE];
    wread(0, buff);
    SuperBlock superB = SuperBlockParse(buff);

    // Mount error with error magic number
    if (superB.MagicNumber != MAGIC_NUMBER)
        return ERR_BAD_MAGIC_NUMBER;

    // Mount error if blocks not enough
    if (superB.Blocks < _disk->Blocks)
        return ERR_NOT_ENOUGH_BLOCKS;

    // Mount error if inodes not enough
    if (superB.InodeBlocks * INODES_PER_BLOCK != superB.Inodes)
        return ERR_NOT_ENOUGH_INODES;

    // Initialize bitmap to mount fs
    _block_bitmap = malloc(sizeof(_Bool) * superB.Blocks);
    _inode_bitmap = malloc(sizeof(_Bool) * superB.Inodes);
    int i;
    for (i = 0; i <= superB.InodeBlocks; i++)
        _block_bitmap[i] = true;
    for (i = superB.InodeBlocks + 1; i < superB.Blocks; i++)
        _block_bitmap[i] = false;
    for (i = 0; i < superB.Inodes; i++)
        _inode_bitmap[i] = false;

    // Parse and store all inodes info for bitmap
    for (i = 1; i <= superB.InodeBlocks; i++) {
        wread(i, buff);
        int j;
        for (j = 0; j < INODES_PER_BLOCK; j++) {
            Inode temp_inode = InodeSoleParse(buff, j);
            int order = (i - 1) * INODES_PER_BLOCK + j;
            if (temp_inode.Valid == 0)
                continue;
            else
                _inode_bitmap[order] = true;

            InodeParseToBitmap(temp_inode);
        }
    }

    _block_bitmap_ptr = locate_free_ptr(_block_bitmap, superB.Blocks);
    _inode_bitmap_ptr = locate_free_ptr(_inode_bitmap, superB.Inodes);

    // Store SuperBlock Info
    superblock_ptr = malloc(sizeof(Block));
    superblock_ptr->Super = superB;

    return SUCCESS_GOOD_MOUNT;
}

ssize_t create() {
    // No free inodes
    if (_inode_bitmap_ptr < 0 || _inode_bitmap_ptr >= superblock_ptr->Super.Inodes)
        return -1;

    ssize_t iNumber = _inode_bitmap_ptr;

    // Initialize an inode
    Inode inode;
    inode.Valid = 1;    // Valid field
    inode.Size = 0; // Size field
    int i;
    for (i = 0; i < 5; i++)
        inode.Direct[i] = 0;    // Direct field
    inode.Indirect = 0;     // Indirect field
    InodeWrite(inode, iNumber);

    // Update the Inode bitmap and bitmap ptr
    _inode_bitmap[_inode_bitmap_ptr] = true;
    _inode_bitmap_ptr = locate_free_ptr(_inode_bitmap, superblock_ptr->Super.Inodes);

    return iNumber;
}

bool wremove(size_t inumber) {

    int inode_block_order = inumber / INODES_PER_BLOCK + 1;
    int inode_unit_number = inumber % INODES_PER_BLOCK;
    int inode_offset = inode_unit_number * INODE_SIZE;

    // Read into inode buff from an inode block
    char inodeBuf[BLOCK_SIZE] = {'\0'};
    wread(inode_block_order, inodeBuf);

    Inode temp_inode = InodeSoleParse(inodeBuf, inode_unit_number);

    // Inode Removal failed if inode not in use
    if (temp_inode.Valid == 0)
        return false;

    BinaryStringWrite(inodeBuf, inode_offset, 0);       // Set Valid field to 0
    BinaryStringWrite(inodeBuf, inode_offset + 4, 0);   // Size field set to 0
    int i;
    for (i = 0; i < 5; i++) {
        int block_order = temp_inode.Direct[i];
        if (block_order == 0)
            break;
        BinaryStringWrite(inodeBuf, inode_offset + 8 + i * 4, 0);   // Direct field set to 0
        _block_bitmap[block_order] = false;     // Update block bitmap
    }

    // Check Indirect field
    if (i == 5 && temp_inode.Indirect != 0) {
        char blockBuf[BLOCK_SIZE];
        wread(temp_inode.Indirect, blockBuf);
        for (i = 0; i < BLOCK_SIZE / 4; i++) {
            // Parse Block Order Number
            long data = BinaryStringParse(blockBuf, i * 4, 4);
            if (data <= 0 || data >= _disk->Blocks)
                break;
            _block_bitmap[data] = false;    // Update block bitmap
        }
    }

    // Write inode info back to realize Inode Removal
    wwrite(inode_block_order, inodeBuf);

    // Update the Inode bitmap and bitmap ptr
    _inode_bitmap[inumber] = false;
    _inode_bitmap_ptr = locate_free_ptr(_inode_bitmap, superblock_ptr->Super.Inodes);

    // Update Block bitmap ptr
    _block_bitmap_ptr = locate_free_ptr(_block_bitmap, superblock_ptr->Super.Blocks);

    return true;
}

ssize_t stat(size_t inumber) {
    // Invalid inode
    if (_inode_bitmap[inumber] == false)
        return -1;
    int inode_block_order = inumber / INODES_PER_BLOCK + 1;
    int inode_unit_number = inumber % INODES_PER_BLOCK;

    char inodeBuf[BLOCK_SIZE] = {'\0'};
    wread(inode_block_order, inodeBuf);
    Inode inode = InodeSoleParse(inodeBuf, inode_unit_number);
    return inode.Size;
}

ssize_t wfsread(size_t inumber, char *data, size_t length, size_t offset) {
    int len = length;

    // Data pointer is NULL
    if (data == NULL) {
        printf("wfsread:Data pointer cannot be null!\n");
        return -1;
    }

    int inode_block_order = inumber / INODES_PER_BLOCK + 1;
    int inode_unit_number = inumber % INODES_PER_BLOCK;

    // Read into inode buff from an inode block
    char Buf[BLOCK_SIZE] = {'\0'};
    wread(inode_block_order, Buf);
    Inode inode = InodeSoleParse(Buf, inode_unit_number);

    // Return if inode is invalid
    if (inode.Valid == 0) {
        printf("wfsread:Indexed inode is invalid!\n");
        return -1;
    }

    int cnt = 0;
    int chunk_order = offset / BLOCK_SIZE;
    int start_addr = offset % BLOCK_SIZE;

    /************* Direct field of inode *************/
    if (chunk_order >= 0 && chunk_order < 5) {
        // No block indicated
        if (inode.Direct[chunk_order] <= 0)
            return cnt;

        while (len > 0) {
            int block_order = inode.Direct[chunk_order];
            wread(block_order, Buf);

            while (len > 0 && start_addr + cnt < BLOCK_SIZE) {
                char tempchar = Buf[start_addr + cnt];
                if (tempchar == '\0')
                    return cnt;
                data[cnt] = Buf[start_addr + cnt];
                cnt++;
                len--;
            }
            // Jump to next inode chunk
            chunk_order++;
            start_addr = 0;

            // Done when length reached
            if (len == 0)
                return cnt;

            // Done even if length not reached but EOF reached
            if (chunk_order < 5 && inode.Direct[chunk_order] <= 0)
                return cnt;

            // Jump to indirect field
            if (chunk_order == 5)
                break;
        }
    }

    /************* Indirect field of inode *************/
    if (inode.Indirect <= 0)
        return cnt;

    int block_order = inode.Indirect;
    wread(block_order, Buf);
    int index = chunk_order - 5;

    while (len > 0 && index < BLOCK_SIZE / 4) {

        long parsed_block = BinaryStringParse(Buf, index * 4, 4);
        // Block order invalid
        if (parsed_block <= 0 || parsed_block >= _disk->Blocks)
            return cnt;

        char tempBuf[BLOCK_SIZE] = {'\0'};
        wread(parsed_block, tempBuf);

        while (len > 0 && start_addr + cnt < BLOCK_SIZE) {
            char tempchar = tempBuf[start_addr + cnt];
            if (tempchar == '\0')
                return cnt;

            data[cnt] = tempBuf[start_addr + cnt];
            cnt++;
            len--;
        }
        index++;
        start_addr = 0;
    }
    return cnt;
}

ssize_t wfswrite(size_t inumber, char *data, size_t length, size_t offset) {
    int len = length;

    // Data pointer is NULL
    if (data == NULL) {
        printf("wfswrite:Data pointer cannot be null!\n");
        return -1;
    }

    int inode_block_order = inumber / INODES_PER_BLOCK + 1;
    int inode_unit_number = inumber % INODES_PER_BLOCK;

    // Read into inode buff from an inode block
    char Buf[BLOCK_SIZE] = {'\0'};
    wread(inode_block_order, Buf);
    Inode inode = InodeSoleParse(Buf, inode_unit_number);

    // Return if inode is invalid
    if (inode.Valid == 0) {
        printf("wfswrite:Indexed inode is invalid!\n");
        return -1;
    }

    int cnt = 0;
    int chunk_order = offset / BLOCK_SIZE;
    int start_addr = offset % BLOCK_SIZE;

    /************* Direct field of inode *************/
    if (chunk_order >= 0 && chunk_order < 5) {

        while (len > 0) {
            // Allocate free block if no block indicated
            if (inode.Direct[chunk_order] <= 0) {
                if (_block_bitmap_ptr != superblock_ptr->Super.Blocks) {
                    BlockInit(_block_bitmap_ptr);       // Block Initialization
                    inode.Direct[chunk_order] = _block_bitmap_ptr;
                } else {  // No more free space
                    inode.Size += cnt;
                    InodeWrite(inode, inumber);
                    return cnt;
                }
                // Update block bitmap and pointer
                _block_bitmap[_block_bitmap_ptr] = true;
                _block_bitmap_ptr = locate_free_ptr(_block_bitmap, superblock_ptr->Super.Blocks);
            }

            // Write data to buffer
            int block_order = inode.Direct[chunk_order];
            wread(block_order, Buf);
            int ii = cnt % BLOCK_SIZE;
            while (len > 0 && start_addr + ii < BLOCK_SIZE) {
                // Write data
                Buf[start_addr + ii] = data[cnt];
                cnt++;
                len--;
                ii++;
            }

            // Write buffer data to disk
            wwrite(block_order, Buf);

            // Jump to next inode chunk
            chunk_order++;
            start_addr = 0;

            // Done when length reached
            if (len == 0) {
                inode.Size += cnt;
                InodeWrite(inode, inumber);
                return cnt;
            }

            // Jump to indirect field
            if (chunk_order == 5)
                break;
        }
    }

    /************* Indirect field of inode *************/
    if (inode.Indirect <= 0) {
        // Allocate free block if no block indicated
        if (_block_bitmap_ptr != superblock_ptr->Super.Blocks) {
            BlockInit(_block_bitmap_ptr);       // Block Initialization
            inode.Indirect = _block_bitmap_ptr;
        } else {   // No more free space
            inode.Size += cnt;
            InodeWrite(inode, inumber);
            return cnt;
        }
        // Update block bitmap and pointer
        _block_bitmap[_block_bitmap_ptr] = true;
        _block_bitmap_ptr = locate_free_ptr(_block_bitmap, superblock_ptr->Super.Blocks);
    }

    int indirect_block = inode.Indirect;
    wread(indirect_block, Buf);
    int block_index_in_indirect = chunk_order - 5;

    while (len > 0 && block_index_in_indirect < BLOCK_SIZE / 4) {
        long parsed_block = BinaryStringParse(Buf, block_index_in_indirect * 4, 4);

        // Allocate a new block node if block order is invalid
        if (parsed_block <= 0 || parsed_block >= _disk->Blocks) {
            if (_block_bitmap_ptr != superblock_ptr->Super.Blocks) {     // Assign block if there's free block
                parsed_block = _block_bitmap_ptr;
                BlockInit(_block_bitmap_ptr);       // Block Initialization
                BinaryStringWrite(Buf, block_index_in_indirect * 4,
                                  _block_bitmap_ptr);    // Update block order in Indirect block
            } else {   // No more free space
                inode.Size += cnt;
                InodeWrite(inode, inumber);
                wwrite(indirect_block, Buf);    // Write back to indirect block for updating block info
                return cnt;
            }
            // Update block bitmap and pointer
            _block_bitmap[_block_bitmap_ptr] = true;
            _block_bitmap_ptr = locate_free_ptr(_block_bitmap, superblock_ptr->Super.Blocks);
        }

        char tempBuf[BLOCK_SIZE] = {'\0'};
        wread(parsed_block, tempBuf);

        int ii = cnt % BLOCK_SIZE;
        while (len > 0 && start_addr + ii < BLOCK_SIZE) {
            tempBuf[start_addr + ii] = data[cnt];
            cnt++;
            len--;
            ii++;
        }

        // Write buffer data to disk
        wwrite(parsed_block, tempBuf);

        block_index_in_indirect++;
        start_addr = 0;
    }

    inode.Size += cnt;
    InodeWrite(inode, inumber);
    wwrite(indirect_block, Buf);     // Write back to indirect block for updating block info
    return cnt;
}


SuperBlock SuperBlockParse(char *data) {
    SuperBlock superB;
    superB.MagicNumber = BinaryStringParse(data, 0, 4);
    superB.Blocks = BinaryStringParse(data, 4, 4);
    superB.InodeBlocks = BinaryStringParse(data, 8, 4);
    superB.Inodes = BinaryStringParse(data, 12, 4);
    return superB;
}

Inode InodeSoleParse(char *inode_block, int index) {
    Inode inode;
    int offset = index * INODE_SIZE;

    // First check valid field
    long isvalid = BinaryStringParse(inode_block, offset, 4);
    inode.Valid = isvalid;

    // Then check the size
    long size = BinaryStringParse(inode_block, offset + 4, 4);
    inode.Size = size;

    // Check remaining 5 fields for field of direct
    int i;
    int cnt = 0;
    for (i = 2; i < 7; i++) {
        long direct = BinaryStringParse(inode_block, offset + 4 * i, 4);
        inode.Direct[cnt++] = direct;
    }

    // Check the last field of indirect
    long indirect = BinaryStringParse(inode_block, offset + 4 * i, 4);
    inode.Indirect = indirect;
    return inode;
}


void BinaryStringWrite(char *data, int index, int srcNumber) {
    char tempBuf[10] = {'0'};
    sprintf(tempBuf, "%08x", srcNumber);
//    printf("tempBuf is:%s\n", tempBuf);
    int cnt;
    for (cnt = 0; cnt < 4; cnt++) {
        char temp[4] = {'\0'};
        strncpy(temp, tempBuf + (3 - cnt) * 2, 2);
        char *str;
        long a = strtol(temp, &str, 16);
        unsigned char c = a;
        data[index + cnt] = c;
    }
}


long BinaryStringParse(char *data, int index, int length) {
    int cnt;
    char charBuff[40] = {'\0'};
    for (cnt = 0; cnt < 4; cnt++) {
        char tempBuff[10];
        unsigned char temp = data[index + length - cnt - 1];
        sprintf(tempBuff, "%02x", temp);
        //printf("tempBuff:%s\n",tempBuff);
        strcat(charBuff, tempBuff);
    }
    char *str;
    const char *bufPointer = charBuff;
    return strtol(bufPointer, &str, 16);
}

void SuperBlockPrint(SuperBlock superB) {
    printf("SuperBlock:\n");
    if (superB.MagicNumber != 0)
        printf("    magic number is valid\n");
    else
        printf("    magic number is invalid\n");
    printf("    %d blocks\n", superB.Blocks);
    printf("    %d inode blocks\n", superB.InodeBlocks);
    printf("    %d inodes\n", superB.Inodes);
}

void InodeParseToBitmap(Inode inode) {
    int i;
    for (i = 0; i < 5; i++)
        if (inode.Direct[i] != 0)
            _block_bitmap[inode.Direct[i]] = true;
        else
            return;
    if (inode.Indirect == 0)
        return;

    // Store Indirect inode info
    _block_bitmap[inode.Indirect] = true;

    char tempBuf[BLOCK_SIZE];
    wread(inode.Indirect, tempBuf);
    for (i = 0; i < BLOCK_SIZE / 4; i++) {
        // Parse Block Order Number
        long data = BinaryStringParse(tempBuf, i * 4, 4);
        if (data <= 0 || data >= _disk->Blocks)
            return;
        _block_bitmap[data] = true;
    }
}

void InodeInfoPrint(Inode inode) {
    printf("    size: %d bytes\n", inode.Size);
    printf("    direct blocks:");
    int i;
    for (i = 0; i < 5; i++) {
        if (inode.Direct[i] != 0)
            printf(" %d", inode.Direct[i]);
        else {
            printf("\n");
            return;
        }
    }

    printf("\n");
    if (inode.Indirect == 0)
        return;
    printf("    indirect block: %d\n", inode.Indirect);

    // Read Indirect Block
    char tempBuf[BLOCK_SIZE];
    wread(inode.Indirect, tempBuf);
    printf("    indirect data blocks:");

    for (i = 0; i < BLOCK_SIZE / 4; i++) {
        // Parse Block Order Number
        long data = BinaryStringParse(tempBuf, i * 4, 4);
        if (data <= 0 || data >= _disk->Blocks) {
            printf("\n");
            return;
        }
        printf(" %ld", data);
    }
}

int locate_free_ptr(_Bool *bitmap, int size) {
    int i;
    for (i = 0; i < size; i++)
        if (bitmap[i] == false)
            return i;
    return size;
}

void print_bitmap(_Bool *ptr, int length) {
    int i;
    for (i = 0; i < length; i++)
        printf("ptr[%d]:%d\n", i, ptr[i]);
}

void InodeWrite(Inode inode, int index) {

    int inode_block_order = index / INODES_PER_BLOCK + 1;
    int inode_offset = (index % INODES_PER_BLOCK) * INODE_SIZE;

    // Read inode block and fill in an inode, then write back
    char inodeBuf[BLOCK_SIZE] = {'\0'};
    wread(inode_block_order, inodeBuf);
    BinaryStringWrite(inodeBuf, inode_offset, inode.Valid);       // Valid field
    BinaryStringWrite(inodeBuf, inode_offset + 4, inode.Size);   // Size field
    int i;
    for (i = 0; i < 5; i++)
        BinaryStringWrite(inodeBuf, inode_offset + 8 + i * 4, inode.Direct[i]);   // Direct field
    BinaryStringWrite(inodeBuf, inode_offset + 28, inode.Indirect);   // Direct field

    wwrite(inode_block_order, inodeBuf);
}

void BlockInit(int blockNum) {
    char tempBuf[BLOCK_SIZE] = {'\0'};
    wwrite(blockNum, tempBuf);
}